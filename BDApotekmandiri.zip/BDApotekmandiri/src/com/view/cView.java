package com.view;

import com.Config.cConfig;
import java.util.Scanner;

public class cView {
  
    public static Scanner input = new Scanner(System.in);
    
  public static void getAllData()
  {
    //  pesan header
    System.out.println("\n::: DATA OBAT :::");
    // data semua barangnya
    System.out.println(cConfig.getAllData());

  }
  
    public static void detailData() 
    {
        System.out.println("\n::: DETAIL DATA OBAT:::");

    System.out.print("Masukkan ID Obat : ");
    int id = input.nextInt();
    
    System.out.println("Hasil Data");
    System.out.println(cConfig.detailData(id));
        
    }
    
    public static void getAllDataPasien()
  {
    //  pesan header
    System.out.println("\n::: DATA SEMUA PASIEN :::");
    // data semua barangnya
    System.out.println(cConfig.getAllDataPasien());

  }
    
    public static void DataPasien() 
    {
        System.out.println("\n::: CARI DATA PASIEN :::");
        
        System.out.print("Masukan ID Pasien : ");
        String id = input.next();
        
        System.out.println("Hasil Data");
        System.out.println(cConfig.DataPasien(id));
        
    }
    
    public static void TambahDataPasien() 
    {
     
        System.out.println("\n::: TAMBAH DATA PASIEN :::");
        System.out.print("Masukan Nama Pasien : ");
        String Nama_Pasien = input.next();
        System.out.print("Masukan Alamat Pasien : ");
        String Alamat_Pasien = input.next();
        
        if (cConfig.TambahDataPasien(Nama_Pasien, Alamat_Pasien) ) {
            System.out.println("Data Pasien berhasil ditambahkan!!");
            cView.getAllDataPasien();
        }else{
            System.out.println("Data Pasien Gagal Ditambahkan");
        }
    }
    
    public static void HapusDataPasien()
    {
        System.out.println("\n::: HAPUS DATA PASIEN :::");
        System.out.print("Masukan ID Pasien : ");
        int Id_Pasien = input.nextInt();
        
        if (cConfig.HapusDataPasien(Id_Pasien) ){
            System.out.println("Data Pasien Berhasil Di Hapus!!");
            cView.getAllDataPasien();
        }else{
            System.out.println("Data Pasien Berhasil Di Hapus!!");
        } 
        
    }
    
    public static void getAllDataTransaksi()
  {
    //  pesan header
    System.out.println("\n::: DATA TRANSAKSI KESELURUHAN :::");
    // data semua barangnya
    System.out.println(cConfig.getAllDataTransaksi());

  }
    
    public static void TambahDataTransaksi() 
    {
     
        System.out.println("\n::: TAMBAH DATA TRANSAKSI :::");
        System.out.print("Masukan ID Transaksi : ");
        int Id_Transaksi = input.nextInt();
        System.out.print("Masukan ID Obat : ");
        int Id_Obat = input.nextInt();
        System.out.print("Masukan ID Pasien : ");
        int Id_Pasien = input.nextInt();
        System.out.print("Masukan Jumlah Beli : ");
        int Jumlah_Beli = input.nextInt();
        
        if (cConfig.TambahDataTransaksi(Id_Transaksi, Id_Obat, Id_Pasien, Jumlah_Beli) ) {
            System.out.println("Data Transaksi berhasil ditambahkan!!");
            cView.getAllDataTransaksi();
        }else{
            System.out.println("Data Transaksi Gagal Ditambahkan");
        }
    }
  

}