package com.Config;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
/**
 *
 * @author ACER
 */
public class cConfig {
    
    // Disini Untuk Mendefinisikan koneksi pada database kita 
    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://localhost/apotekmandiri";
    static final String USER = "root";
    static final String PASS = "";
    
    //Disini Untuk Meinstan kan object dari class yang sudah di import 
    static Connection connect;
    static Statement statement;
    static ResultSet resultdata;
    
    //Dan Ini adalah method dari static connection
    public static void Connection()
    {
        //method untuk melakukan koneksi ke database
        try {
            //Registrasi driver yang akan di pakai
            DriverManager.registerDriver(new com.mysql.jdbc.Driver());
            connect = DriverManager.getConnection(DB_URL, USER, PASS);
                    
        } catch (Exception e) {
            //jikalau ada error saat koneksi
            e.printStackTrace();
        }
    }
    public static String getAllData() 
    {
        cConfig.Connection();
        
        String data = "Maaf data Tidak Di Temukan ";
        
        try {
            
            statement = connect.createStatement();
            
            String query = "SELECT Id_Obat, Nama_Obat FROM tbl_obat;";
            
            resultdata = statement.executeQuery(query);
            
            data = "";
            
            while (resultdata.next() ){
                data += "Id_Obat : " + resultdata.getString("id_Obat") + ", Nama_Obat : " + resultdata.getString("nama_obat") + "\n";
            }                
                
            
            statement.close();
            connect.close();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
return data;

}
    
    public static String detailData(int id) 
    {
     cConfig.Connection();
     
     String data = "Data Tidak Obat Di temukan";
     
        try {
            
            statement = connect.createStatement();
            
            String query ="SELECT * FROM `tbl_obat` WHERE `Id_Obat` = " + id;
            
            resultdata = statement.executeQuery(query);
            
            data = "";
            
            if( resultdata.next() ){
        data += "- ID Obat : " + resultdata.getInt("Id_Obat")
          + "\n- Nama Obat : " + resultdata.getString("Nama_Obat")
          + "\n- Harga Obat : Rp." + resultdata.getInt("Harga_Obat")
          + "\n- Stock Obat : " + resultdata.getInt("Stock_Obat");
            }else{
            System.out.println("Data Obat Tidak Di Temukan ");
      
            
        }             
            
            statement.close();
            connect.close();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        return data;
    }
    
    public static String getAllDataPasien() 
    {
        cConfig.Connection();
        
        String data = "Maaf data Pasien tidak Di Temukan";
        
        try {
            
            statement = connect.createStatement();
            
            String query = "SELECT Id_Pasien, Nama_Pasien, Alamat_Pasien FROM tbl_pasien ";
            
            resultdata = statement.executeQuery(query);
            
            data = "";
            
            while (resultdata.next() ){
                data += "Id_Pasien : " + resultdata.getString("id_Pasien") + ", Nama_Pasien : " + resultdata.getString("nama_pasien") + ", Alamat_Pasien : " + resultdata.getString("alamat_pasien") + "\n";
            }                
                
            
            statement.close();
            connect.close();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
return data;
    }
    
    public static String DataPasien(String id) 
    {
        cConfig.Connection();
        
        String data = " ";
        
        try {
            
            statement = connect.createStatement();
            
            String query = "SELECT * FROM tbl_pasien WHERE Id_Pasien = " + id;
            
            resultdata = statement.executeQuery(query);
            
            data ="";
            
            if( resultdata.next() ){
        data += "- ID Pasien : " + resultdata.getInt("Id_Pasien")
          + "\n- Nama Pasien : " + resultdata.getString("Nama_Pasien")
          + "\n- Alamat Pasien : " + resultdata.getString("Alamat_Pasien");
            }else{
            System.out.println("Data Pasien Tidak Di Temukan ");  
            
            }
            
            statement.close();
            connect.close();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    return data;

    }
    public static boolean TambahDataPasien(String Nama_Pasien, String Alamat_Pasien) 
    {
        {
            cConfig.Connection();
            boolean data = false;
            
            try {
                
                statement = connect.createStatement();
                
                String query = "INSERT INTO tbl_pasien VALUES (" + null + ", '" + Nama_Pasien + "', " + "'" + Alamat_Pasien + "'" + ")";
                
                if( !statement.execute(query) ){
                    data = true;
                }
                
                statement.close();
                connect.close();
                
            } catch (Exception e) {
                e.printStackTrace();
            }
            
            return data;
        }    
    
}
    
    public static boolean HapusDataPasien(int Id_Pasien) 
    {
     cConfig.Connection();
     boolean data = false;
     
        try {
         
            statement = connect.createStatement();
            
            String query = "DELETE FROM tbl_pasien WHERE Id_Pasien = " + Id_Pasien;
            
            if (statement.execute(query)) {
                data = true;
            }
           
        } 
        catch (Exception e) {
          e.printStackTrace();
        }
        return data;
    }
    
    public static String getAllDataTransaksi() 
    {
        cConfig.Connection();
        
        String data = "Maaf data Transaksi tidak Di Temukan";
        
        try {
            
            statement = connect.createStatement();
            
            String query = "SELECT Id_Transaksi, Id_Obat, Id_Pasien, Jumlah_Beli FROM tbl_transaksi;";
            
            resultdata = statement.executeQuery(query);
            
            data = "";
            
            while (resultdata.next() ){
                data += "Id_Transaksi : " + resultdata.getString("id_Transaksi") + ", Id_Obat : " + resultdata.getString("id_obat") + ", Id_Pasien : " + resultdata.getString("id_Pasien") + ", Jumlah_Beli : " + resultdata.getString("jumlah_beli") + "\n";
            }                
                
            
            statement.close();
            connect.close();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
return data;

}
    
        public static boolean TambahDataTransaksi(int Id_Transaksi, int Id_Obat, int Id_Pasien, int Jumlah_Beli) 
    {
        {
            cConfig.Connection();
            boolean data = false;
            
            try {
                
                statement = connect.createStatement();
                
                String query = "INSERT INTO tbl_transaksi VALUES (" + Id_Transaksi + ", " + Id_Obat + ", " + Id_Pasien + "," + Jumlah_Beli + ")";
                
                if( !statement.execute(query) ){
                    data = true;
                }
                
                statement.close();
                connect.close();
                
            } catch (Exception e) {
                e.printStackTrace();
            }
            
            return data;
        }    
    
}
        
        

}
    
     

     