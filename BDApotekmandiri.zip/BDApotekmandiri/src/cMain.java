import java.util.Scanner;
import com.view.cView;

public class cMain {
    
    public static void main(String[] args) {
        
        while (true) {

            System.out.print("\n=== MENU ===\n"
            + "1. Lihat Semua Data Obat\n"
            + "2. Detail Data Obat\n"
            + "3. Lihat Semua Data Pasien\n"
            + "4. Cari Data Pasien\n"
            + "5. Tambah Data Pasien\n"
            + "6. Hapus Data Pasien\n"
            + "7. Lihat Semua Data Transaksi\n"
            + "8. Tambah Data Transaksi\n"
            + "0. Exit\n"
            + "Pilih[1/2/3/4/5/6/7/8/0] : ");
            
            Scanner input = new Scanner(System.in);
            String pilihan = input.next();

            if( pilihan.equalsIgnoreCase("0") ){
                System.out.println("Terimakasih Selamat Datang Kembali!!");
                break;
            }

            switch (pilihan) {
                case "1" :
                    cView.getAllData();
                    break;
                case "2" :
                    cView.detailData();
                    break;
                case "3" :
                    cView.getAllDataPasien();
                    break;    
                case "4" :
                    cView.DataPasien();
                    break;
                case "5" :
                    cView.TambahDataPasien();
                    break;
                case "6" :
                    cView.HapusDataPasien();
                    break;
                case "7" :
                    cView.getAllDataTransaksi();
                    break;
                case "8" :
                    cView.TambahDataTransaksi();
                    break;    
                default:
                    System.out.println("Pilihan salah!!");
                    break;
            }


        }

    }
}
        
        
    
    
